df <- read.csv("D:/bigData/Detailed_Statistics_Departures.csv",header=TRUE, sep = ",")
nrow(df)
ncol(df)
names(df)
is.na(df)


winter.flights <- subset(df, subset = (Month == 1 | Month == 2 | Month ==3))
summer.flights <- subset(df, subset = (Month == 6 | Month == 7 | Month ==8))
round(mean(winter.flights$DepartureDelayMinutes, na.rm = T), 2)
round(mean(summer.flights$DepartureDelayMinutes, na.rm = T), 2)
round(median(winter.flights$DepartureDelayMinutes, na.rm = T), 2)
round(median(summer.flights$DepartureDelayMinutes, na.rm = T), 2)
round(sd(winter.flights$DepartureDelayMinutes, na.rm = T), 2)
round(sd(summer.flights$DepartureDelayMinutes, na.rm = T), 2)
round(summary(winter.flights$DepartureDelayMinutes),2)
round(summary(summer.flights$DepartureDelayMinutes),2)

t.test(winter.flights$DepartureDelayMinutes, summer.flights$DepartureDelayMinutes, mu = 0, paired = F, var.equal = F, conf.level = 0.95)


q2 <- subset(df, subset = (ActualElapsedTimeMinutes > 0 ))
hist(q2$ActualElapsedTimeMinutes[q2$DestinationAirport == "IAH"], breaks = 100, col = "green" , border = "black",
     main = "Histogram of elapsed time for flights to Houston",xlab = "elapsed time of flight, in minutes", ylab = "number of flights")

abline(v = mean(q2$ActualElapsedTimeMinutes[q2$DestinationAirport == "IAH"], na.rm = T), col = "red", lwd = 2)
abline(v = median(q2$ActualElapsedTimeMinutes[q2$DestinationAirport == "IAH"], na.rm = T), col = "blue", lwd = 2)


mean.delay.dest <- aggregate(formula = DepartureDelayMinutes + DelayLateAircraftArrivalMinutes ~ DestinationAirport
                             , FUN = mean, na.rm = TRUE, data = df)

mean.delay.dest$'DepartureDelayMinutes + DelayLateAircraftArrivalMinutes'[mean.delay.dest$DestinationAirport== "IAH"]

summary(mean.delay.dest)

which.max(mean.delay.dest$`DepartureDelayMinutes + DelayLateAircraftArrivalMinutes`)
mean.delay.dest$DestinationAirport[4]



